/**
 * TEMPORARY DIAGNOSTIC FIRMWARE -- not the real robotic-arm firmware.
 *
 * Does the absolute minimum: opens serial, prints READY, and answers PING
 * with PONG. Deliberately touches NO GPIO pins whatsoever -- no pinMode(),
 * no digitalWrite(), nothing -- so whatever is soldered onto GPIO18/19/25/26
 * (relays) or GPIO21 (laser) cannot possibly affect this firmware's behavior.
 *
 * Purpose: if the real firmware reset-loops (repeated READY) but THIS one
 * stays up cleanly and answers PING, that proves the loop is caused by the
 * real firmware driving those pins (almost certainly a relay-coil brownout)
 * -- not a dead/damaged ESP32, not a bad flash, not a serial/driver issue.
 *
 * Once you're done testing, reflash the real ESP32_Laser_Control firmware.
 */

#include <Arduino.h>

String inputBuffer;

void setup() {
    Serial.begin(115200);
    delay(500);
    inputBuffer.reserve(64);
    Serial.print("READY (DIAGNOSTIC BUILD - no GPIO touched)\r\n");
}

void loop() {
    while (Serial.available()) {
        char c = static_cast<char>(Serial.read());
        if (c == '\n' || c == '\r') {
            if (inputBuffer.length() > 0) {
                String cmd = inputBuffer;
                cmd.trim();
                cmd.toUpperCase();
                if (cmd == "PING") {
                    Serial.print("PONG\r\n");
                } else {
                    Serial.print("DIAG: got '");
                    Serial.print(cmd);
                    Serial.print("' (diagnostic build only understands PING)\r\n");
                }
                inputBuffer = "";
            }
        } else if (inputBuffer.length() < 60) {
            inputBuffer += c;
        }
    }
}
